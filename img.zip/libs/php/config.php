
<?php

	// connection details for MySQL database

	// $cd_host = "127.0.0.1";
	// $cd_port = 3306;
	// $cd_socket = "";

	$cd_host = "localhost";
	$cd_port = 3306;
	$cd_socket = "";

	// database name, username and password

	// $cd_dbname = "companydirectory";
	// $cd_user = "companydirectory";
	// $cd_password = "companydirectory";

	$cd_dbname = "thecqvlm_company_directory";
	$cd_user = "thecqvlm_company_directory_user";
	$cd_password = "7EB]?9}q(WA2";


	

?>
